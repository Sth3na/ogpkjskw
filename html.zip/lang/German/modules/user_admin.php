<?php
/*
 *
 * OGP - Open Game Panel
 * Copyright (C) Copyright (C) 2008 - 2013 The OGP Development Team
 *
 * http://www.opengamepanel.org/
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

define('your_profile', "Dein Profil");
define('new_password', "Neues Passwort");
define('retype_new_password', "Passwort wiederholen");
define('login_name', "Benutzername");
define('language', "Sprache");
define('first_name', "Vorname");
define('last_name', "Nachname");
define('phone_number', "Telefonnummer");
define('email_address', "E-Mail Adresse");
define('city', "Stadt");
define('province', "Bundesland/Kanton");
define('country', "Land");
define('comment', "Kommentar");
define('expires', "L�uft ab");
define('save_profile', "Profil speichern");
define('new_password_info', "When password field is empty the password will not be updated.");
define('theme', "Theme");
define('theme_info', "If theme is empty the global value is used.");
define('expires_info', "Date when the user account expires. The account is not deleted, but user can not login anymore.");
define('password_mismatch', "Die Passw�rter stimmen nicht �berein.");
define('current_password', "Aktuelles Passwort");
define('current_password_info', "Dein aktuelles Passwort.");
define('current_password_mismatch', "Your current password did not match to the one in database.");

// show_users.php
define('add_new_user', "Neuen Benutzer hinzuf�gen");
define('edit_user_groups', "Edit User Groups");
define('users', "Benutzer");
define('user_role', "Rolle");
define('full_name', "Full Name");
define('edit_games', "Edit Games");
define('edit_profile', "Profil bearbeiten");

// add_user.php
define('confirm_password', "Passwort wiederholen");
define('you_need_to_enter_both_passwords', "You need to enter both passwords.");
define('passwords_did_not_match', "Die Passw�rter stimmen nicht �berein.");
define('could_not_add_user_because_user_already_exists', "Could not add user, because user <em>%s</em> already exists.");
define('successfully_added_user', "Successfully added user <em>%s</em>.");
define('add_a_new_user', "Add a new user");
define('admin', "Admin");
define('user', "User");
define('add_user', "Add User");
define('user_with_id_does_not_exist', "User with ID %s does not exist.");
define('are_you_sure_you_want_to_delete_user', "Are you sure you want to delete user <em>%s</em>?");
define('unable_to_delete_user', "Unable to delete user %s.");
define('successfully_deleted_user', "Successfully deleted user <b>%s</b>.");
define('failed_to_update_user_profile_error', "Failed to update user profile. Error: %s");
define('profile_of_user_modified_successfully', "Profile of user <b>%s</b> was modified successfully.");

// subuser used in show_groups.php
define('no_subusers', "No subusers are available to be assigned to a group. Please create subuser accounts.");
define('ownedby', "Parent Owner");
define('andSubUsers', " And all of his subusers?"); 

// *_group.php
define('info_group', "From this page it is possible to determine user groups. You can assign servers to group so that they are availble for all of the group users.");
define('add_new_group', "Neue Gruppe hinzuf�gen");
define('group_name', "Gruppen Name");
define('add_group', "Gruppe hinzuf�gen");
define('no_groups_available', "Keine Gruppen verf�gbar.");
define('delete_group', "Gruppe l�schen");
define('add_user_to_group', "Benutzer zur Gruppe hinzuf�gen");
define('remove_from_group', "Benutzer von Gruppe entfernen");
define('add_server_to_group', "Add server to group");
define('add_server', "Add Server");
define('no_remote_servers', "No remote servers available.");
define('servers_in_group', "Servers in group");
define('no_servers_in_group', "No servers in group %s.");
define('available_groups', "Verf�gbare Gruppen");
define('assign_homes', "Homes zuweisen");

// add_group.php
define('successfully_added_group', "Successfully added group %s.");
define('group_name_empty', "Group name can not be empty.");
define('failed_to_add_group', "Failed to add group %s.");
define('could_not_add_user_to_group', "Could not add user %s to group %s, because already belongs.");
define('successfully_added_to_group', ">Successfully added %s to group <em>%s</em>.");
define('could_not_add_server_to_group', "Could not add server to group %s, because already belongs.");
define('successfully_added_server_to_group', "Successfully added server to group <em>%s</em>.");
define('successfully_removed_from_group', "Successfully removed %s from group <em>%s</em>.");
define('could_not_delete_server_from_group', "Could not delete server %s from group <em>%s</em>.");
define('successfully_removed_server_from_group', "Successfully removed server %s from group <em>%s</em>.");
define('group_with_id_does_not_exist', "User with ID %s does not exist.");
define('are_you_sure_you_want_to_delete_group', "Are you sure you want to delete group <em>%s/em>?");
define('unable_to_delete_group', "Unable to delete user %s.");
define('successfully_deleted_group', "Successfully deleted group <b>%s</b>.");
?>
